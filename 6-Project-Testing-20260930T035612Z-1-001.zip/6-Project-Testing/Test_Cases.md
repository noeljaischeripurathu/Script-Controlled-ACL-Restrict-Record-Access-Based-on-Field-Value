# Phase 6: Project Testing

## 6.1 Test Objective
Confirm that the Read, Create, Write and Delete ACLs on `u_institution_details` allow and deny access exactly as designed for each type of user.

## 6.2 Test Environment
| Item | Detail |
|------|--------|
| Platform | ServiceNow instance (Global scope) |
| Table | `u_institution_details` |
| Test data | 6 records: 2 EEE, 2 ECE, 2 CSE |
| Users | EEE User (bb1–bb4), a user without the roles, admin |
| Method | Impersonate each user and open `u_institution_details.list` |
| Testers | Noel Jais (C4S32208), Nisha Devi P (C4S32202), Selvinkumar S (C4S32210) |

## 6.3 Test Approach
1. Start as admin and confirm all six records exist.
2. Impersonate each user in turn.
3. Open the list by pasting `u_institution_details.list` into the All menu filter.
4. Record what is visible (records, New button, edit, delete).
5. Compare with the expected result and mark Pass or Fail.

## 6.4 Test Cases
| ID | User / Roles | Action | Expected Result | Actual | Status |
|----|--------------|--------|-----------------|--------|--------|
| TC-1 | bb1 | Open list | Only EEE records (2) visible | Only 2 EEE records shown | Pass |
| TC-2 | No roles | Open list | No records to display | "No records to display" | Pass |
| TC-3 | admin | Open list | All 6 records visible | All 6 shown | Pass |
| TC-4 | bb1 + bb2 | Open list | EEE records + New button | New button visible | Pass |
| TC-5 | bb1 + bb2 + bb3 | Edit Description in list | Edit allowed and saved | "ACL is Executed" saved | Pass |
| TC-6 | bb1 + bb2 + bb3 + bb4 | Delete an EEE record | Delete allowed | Record deleted | Pass |
| TC-7 | bb1 only | Try New / edit / delete | Not available | Not available | Pass |

## 6.5 Detailed Test Procedures

### TC-1 – bb1 user sees only EEE records
- **Precondition:** Read ACL is active; user has bb1.
- **Steps:** Impersonate the user → open `u_institution_details.list`.
- **Expected:** Only records with Branch = EEE (INS0001007, INS0001004).
- **Result:** Pass.

### TC-2 – User without roles sees nothing
- **Precondition:** User has none of bb1–bb4.
- **Steps:** Impersonate the user → open the list.
- **Expected:** "No records to display".
- **Result:** Pass.

### TC-3 – Admin sees all records
- **Precondition:** Logged in as admin (Admin overrides is on).
- **Steps:** Open the list.
- **Expected:** All 6 records from ECE, CSE and EEE.
- **Result:** Pass.

### TC-4 – Create ACL (bb2) shows the New button
- **Precondition:** Create ACL active; user has bb1 + bb2.
- **Steps:** Open the list and look at the top right.
- **Expected:** EEE records only, plus the **New** button.
- **Result:** Pass.

### TC-5 – Write ACL (bb3) allows editing
- **Precondition:** Write ACL active; user has bb1 + bb2 + bb3.
- **Steps:** Double-click Description in an EEE row → enter "ACL is Executed" → click the green tick.
- **Expected:** Value saved.
- **Result:** Pass.

### TC-6 – Delete ACL (bb4) allows deleting
- **Precondition:** Delete ACL active; user has bb1 + bb2 + bb3 + bb4.
- **Steps:** Tick an EEE record → Actions on selected rows → Delete → confirm.
- **Expected:** Record is deleted.
- **Result:** Pass.

### TC-7 – Missing roles hide actions
- **Precondition:** User has only bb1.
- **Steps:** Open the list and look for New, inline edit and Delete.
- **Expected:** None of them are available.
- **Result:** Pass.

## 6.6 Evidence
| Test | Screenshot |
|------|-----------|
| TC-1 | [15_verify_bb1_only_eee_records](../5-Project-Development/screenshots/15_verify_bb1_only_eee_records.png) |
| TC-2 | [16_verify_no_role_no_records](../5-Project-Development/screenshots/16_verify_no_role_no_records.png) |
| TC-3 | [17_verify_admin_all_records](../5-Project-Development/screenshots/17_verify_admin_all_records.png) |
| TC-4 | [20_verify_new_button_bb1_bb2](../5-Project-Development/screenshots/20_verify_new_button_bb1_bb2.png) |
| TC-5 | [23_verify_inline_edit_bb3](../5-Project-Development/screenshots/23_verify_inline_edit_bb3.png), [24_verify_description_saved](../5-Project-Development/screenshots/24_verify_description_saved.png) |
| TC-6 | [27_delete_action_menu](../5-Project-Development/screenshots/27_delete_action_menu.png), [28_delete_confirmation](../5-Project-Development/screenshots/28_delete_confirmation.png) |

## 6.7 Test Summary
| Metric | Value |
|--------|-------|
| Total test cases | 7 |
| Passed | 7 |
| Failed | 0 |
| Pass rate | 100% |

**Conclusion:** All read, create, write and delete ACL behaviours match the design.

## 6.8 Defects Found
None during this test cycle.

## 6.9 Further Checks You Can Try (Optional)
These extra ideas are suggestions for deeper practice and are not part of the recorded results above.
- Open a record's form directly from its URL as a user without bb1 and confirm access is denied.
- Try the same list through a report or the Service Portal to see that the server-side ACL still applies.
- Temporarily deactivate the Read ACL and observe the difference, then reactivate it.

**Tested by:** Noel Jais (C4S32208), Nisha Devi P (C4S32202), Selvinkumar S (C4S32210)
