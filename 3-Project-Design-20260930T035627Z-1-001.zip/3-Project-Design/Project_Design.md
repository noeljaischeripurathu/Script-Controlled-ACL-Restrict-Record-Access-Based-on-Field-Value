# Phase 3: Project Design

## 3.1 Design Overview
The design places four ACL records on the custom table `u_institution_details`. Each ACL protects one operation. The read ACL is the most detailed: it needs a role, a data condition and a script to all be true before a record is shown.

## 3.2 How ServiceNow Evaluates an ACL
For an **Allow If** ACL, access is granted only when **all** of these are true:
1. **Role** – the user holds at least one role listed under *Requires role* (admins pass automatically when *Admin overrides* is on).
2. **Data condition** – the record matches the condition (for the read ACL: Branch is EEE).
3. **Script** – the advanced script returns `true` (or sets `answer = true`).

If any part fails, that ACL does not grant access. If no ACL grants access, the user is denied.

## 3.3 Architecture Diagram
```
                 User opens u_institution_details.list
                                  |
                                  v
                   ServiceNow checks ACLs for the table
                                  |
        +-------------------------+--------------------------+
        |                         |                          |
   Role check                Data condition             Script check
 (bb1 / bb2 / ...)        (Branch is EEE)         (gs.hasRole('admin'/'bb1'))
        |                         |                          |
        +-------------------------+--------------------------+
                                  |
                        All conditions true?
                          /              \
                       Yes                No
                        |                  |
              Record / action        Record hidden or
                 is allowed          action unavailable
```

## 3.4 Read ACL – Decision Flow
```
Start
  |
  v
Does user have role bb1 (or admin override)?  --No--> DENY
  | Yes
  v
Is record Branch = EEE?                        --No--> DENY (record hidden)
  | Yes
  v
Script: gs.hasRole('admin')?                   --Yes-> ALLOW
  | No
  v
Script: gs.hasRole('bb1')?                     --Yes-> ALLOW
  | No
  v
DENY
```

## 3.5 ACL Design Table
| ACL | Type | Operation | Decision type | Requires role | Data condition | Advanced | Admin overrides |
|-----|------|-----------|---------------|---------------|----------------|----------|-----------------|
| u_institution_details | record | read | Allow If | bb1 | Branch is EEE | Yes (script) | Yes |
| u_institution_details | record | create | Allow If | bb2 | None | No | Yes |
| u_institution_details | record | write | Allow If | bb3 | None | No | Yes |
| u_institution_details | record | delete | Allow If | bb4 | None | No | Yes |

## 3.6 Role Design
| Role | Purpose |
|------|---------|
| bb1 | Lets a user **read** Institution Details records that match the data condition |
| bb2 | Lets a user **create** new Institution Details records (New button) |
| bb3 | Lets a user **write** (edit) Institution Details records |
| bb4 | Lets a user **delete** Institution Details records |

## 3.7 Data Model
```
+-------------------------------+
| u_institution_details         |
+-------------------------------+
| Student Roll Number (String)  |---> auto-number default
| Student Name (Reference)      |---> sys_user
| Faculty Name (Reference)      |---> sys_user
| Branch (Choice: ECE/EEE/CSE)  |---> used by the ACL data condition
| Email (String)                |
| Phone Number (String)         |
| Description (String, long)    |
+-------------------------------+
```

## 3.8 Read ACL Script
```javascript
(function () {
    // Allow admin users full access
    if (gs.hasRole('admin')) {
        return true;
    }
    // Users with bb1 pass the script check.
    // EEE-only visibility comes from the ACL data condition "Branch is EEE".
    if (gs.hasRole('bb1')) {
        return true;
    }
    // Deny access for all others
    return false;
})();
```
**Line-by-line explanation**
- `(function () { ... })();` – an immediately invoked function; its return value becomes the ACL result.
- `gs.hasRole('admin')` – checks whether the current session user has the admin role.
- `return true` – grants access at once for admins.
- `gs.hasRole('bb1')` – checks for the custom read role.
- `return false` – denies access to everyone else (default deny).

## 3.9 Design Decisions
| Decision | Reason |
|----------|--------|
| Use a data condition for the branch filter | Conditions are evaluated per record and are easier to read than script logic |
| Use a script for role logic | Demonstrates script-controlled ACLs as required by the lab |
| One role per operation | Follows least privilege and lets access be mixed and matched |
| No data condition on create/write/delete | Their reach is limited by the read ACL, since users only act on records they can see |
| Keep table non-extended | Simple, self-contained table for the lab |

## 3.10 Security Considerations
- Enforcement is on the server, so it applies to lists, forms, reports and the Service Portal.
- The script ends with `return false`, so the default is deny.
- Roles are custom (bb1–bb4) and are not reused for other purposes.
- Only `security_admin` can create or edit ACLs.

## 3.11 User Interface Behaviour (Design Target)
| User | List view | New button | Inline edit | Delete action |
|------|-----------|------------|-------------|---------------|
| bb1 | EEE records only | Hidden | Not available | Not available |
| bb1 + bb2 | EEE records only | Shown | Not available | Not available |
| bb1 + bb2 + bb3 | EEE records only | Shown | Available | Not available |
| bb1 + bb2 + bb3 + bb4 | EEE records only | Shown | Available | Available |
| No role | Empty list | Hidden | – | – |
| admin | All records | Shown | Available | Available |
