# Phase 7: Project Documentation

## 7.1 Document Index
| Document | Location |
|----------|----------|
| Original lab guide (PDF with screenshots) | [Script-Controlled_ACL-Micro_Projects.pdf](Script-Controlled_ACL-Micro_Projects.pdf) |
| Ideation | [Phase 1](../1-Brainstorming-Ideation/Brainstorming_and_Ideation.md) |
| Requirements | [Phase 2](../2-Requirement-Analysis/Requirement_Analysis.md) |
| Design | [Phase 3](../3-Project-Design/Project_Design.md) |
| Planning | [Phase 4](../4-Project-Planning/Project_Planning.md) |
| Development steps and screenshots | [Phase 5](../5-Project-Development/Development_Steps.md) |
| Testing | [Phase 6](../6-Project-Testing/Test_Cases.md) |
| Demonstration | [Phase 8](../8-Project-Demonstration/Demonstration.md) |

## 7.2 Abstract
This project implements **record-level security** on a custom ServiceNow table, `u_institution_details`, using **script-controlled Access Control Lists**. The read ACL combines a role requirement (bb1), a data condition (Branch is EEE) and a server-side script that allows admins and bb1 holders and denies everyone else. Separate ACLs use roles bb2, bb3 and bb4 to control creating, editing and deleting records. Testing by impersonation confirmed that an EEE user sees only EEE records, a user without roles sees nothing and an admin sees everything.

## 7.3 Introduction
Access Control Lists are the core of ServiceNow security. They decide whether a user can read, write, create or delete data. A well-designed ACL protects sensitive information without blocking legitimate work. This project shows how to build such rules for a student-records table.

## 7.4 Key Concepts
| Term | Meaning |
|------|---------|
| ACL | A rule that grants or denies access to a table, record or field for an operation |
| Operation | Read, write, create or delete |
| Role | A named permission that can be assigned to users |
| Data condition | A filter on record field values that must match for access |
| Advanced ACL | An ACL that also runs a script to decide access |
| Admin overrides | Setting that lets admins pass the ACL automatically |
| Impersonation | Temporarily acting as another user to test their access |
| security_admin | Elevated role needed to create or edit ACLs |
| gs.hasRole() | Server-side method that returns true if the current user has a role |

## 7.5 System Summary
| Component | Value |
|-----------|-------|
| Table | u_institution_details (Institution Details) |
| Fields | Student Roll Number, Student Name, Faculty Name, Branch, Email, Phone Number, Description |
| Test user | EEE User |
| Roles | bb1 (read), bb2 (create), bb3 (write), bb4 (delete) |
| ACLs | 4 (read, create, write, delete) |
| Sample records | 6 (2 ECE, 2 CSE, 2 EEE) |

## 7.6 Results
| Scenario | Result |
|----------|--------|
| bb1 user | Sees only EEE records |
| User without roles | Sees "No records to display" |
| Admin | Sees all records |
| bb1 + bb2 | New button appears |
| bb1 + bb2 + bb3 | Records can be edited |
| bb1 + bb2 + bb3 + bb4 | Records can be deleted |

## 7.7 Learning Outcomes
- How READ, WRITE, CREATE and DELETE ACLs enforce record-level security.
- How user roles and record field values are evaluated together to make an access decision.
- How ACLs protect sensitive data from unauthorized viewing, modification, creation and deletion across forms, lists and Service Portal interfaces.
- How to use elevated roles and impersonation safely when working with security.

## 7.8 Best Practices Followed
- Elevate to `security_admin` only when needed.
- Use one role per operation (least privilege).
- Prefer data conditions for field-based filtering and keep scripts short.
- Default to deny at the end of the script.
- Test with three user types: a role holder, a user without roles and an admin.
- Keep the ACL list tidy by naming the table exactly.

## 7.9 Limitations
- The Read ACL script gives the same result for every bb1 user; the Branch filter comes from the data condition, not from the user's own branch.
- Only one branch (EEE) is protected in this lab. Other branches would need their own ACLs and roles.
- Testing is done on a single instance with a small data set.

## 7.10 Future Enhancements
- Add matching ACLs for ECE and CSE branches.
- Link the user's branch to a field on the user record so one script can serve every branch.
- Add field-level ACLs to hide Email and Phone Number from users who do not need them.
- Group the roles into a single container role for easier assignment.
- Package the work into a scoped application for easy deployment.

## 7.11 Conclusion
The project met all its goals. Users see and change only the data they are authorized for, while admins retain full access. The same approach can secure any table that needs role and field-based rules.

## 7.12 References
- ServiceNow Product Documentation – Access Control Rules
- ServiceNow Developer Documentation – GlideSystem (`gs.hasRole`)
- Lab guide: Script-Controlled ACL – Restrict Record Access Based on Field Value (PDF in this folder)

## 7.13 Submitted By
| S.No | Name | Reg No | Department |
|------|------|--------|------------|
| 1 | Noel Jais | C4S32208 | Physics |
| 2 | Nisha Devi P | C4S32202 | Physics |
| 3 | Selvinkumar S | C4S32210 | Physics |

- **College:** Mary Matha College of Arts and Science, Periyakulam, Theni
- **GitHub:** https://github.com/noeljaischeripurathu/Script-Controlled-ACL-Restrict-Record-Access-Based-on-Field-Value
- **Demo video:** https://drive.google.com/file/d/1otBEL14NNOl1m77vg9nPVpjpeB7yMm5c/view?usp=drivesdk
