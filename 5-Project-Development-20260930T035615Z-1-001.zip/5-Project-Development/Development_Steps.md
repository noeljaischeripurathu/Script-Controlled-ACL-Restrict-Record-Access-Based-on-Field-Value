# Phase 5: Project Development

This phase records every build step. All screenshots are in the [`screenshots/`](screenshots/) folder and the ACL script is in [`scripts/read_acl_script.js`](scripts/read_acl_script.js).

---

## Milestone 1 – Creation of Users and Roles

### 1.1 User creation
1. Log in to the ServiceNow instance with **admin** access.
2. In the **Application Navigator** (All menu), type `users` in the filter box.
3. Under **Users and Groups**, click **Users**.
4. Click **New**.
5. Fill in the form:
   | Field | Value |
   |-------|-------|
   | User ID | `EEEUser` |
   | First name | `EEE` |
   | Last name | `User` |
   | Email | `eeeuser@gmail.com` |
6. Leave **Active** ticked.
7. Click **Update** / **Submit** to save the record.

![Users navigation](screenshots/01_users_navigation.png)
![EEE User form](screenshots/02_eee_user_form.png)

### 1.2 Role creation
1. In the Application Navigator, type `roles` and open **Users and Groups > Roles**.
2. Click **New**.
3. Enter **Name** `bb1` and a short **Description** of its purpose (for example, "Read access to Institution Details").
4. Click **Submit**.
5. Repeat the same procedure to create **bb2**, **bb3** and **bb4**.

| Role | Purpose |
|------|---------|
| bb1 | Read records |
| bb2 | Create records |
| bb3 | Write (edit) records |
| bb4 | Delete records |

![Roles navigation](screenshots/03_roles_navigation.png)
![Role BB1](screenshots/04_role_bb1.png)

### 1.3 Assign roles to the EEE User
1. Open the **EEE User** record.
2. In the **Roles** related list, click **Edit**.
3. Move **bb1, bb2, bb3, bb4** to the *Roles List* and click **Save**.
4. Confirm the four roles are listed for the user.

✅ **Milestone 1 result:** one test user with four custom roles.

---

## Milestone 2 – Creation of the Table

### 2.1 Create the custom table
1. In the Application Navigator, search for **System Definition > Tables**.
2. Click **New**.
3. Enter:
   | Field | Value |
   |-------|-------|
   | Label | `Institution Details` |
   | Name | `u_institution_details` |
   | Extends table | *(empty / false)* |
4. Click **Submit**.

![Tables navigation](screenshots/05_tables_navigation.png)
![Institution Details table](screenshots/06_table_institution_details.png)

### 2.2 Add the fields
Open the table and add these columns in the **Columns** section:

| Column label | Type | Notes |
|--------------|------|-------|
| Student Roll Number | String | Default value: `javascript:global.getNextObjNumberPadded();` |
| Student Name | Reference | Reference table: User |
| Faculty Name | Reference | Reference table: User |
| Branch | Choice | Choices: ECE, EEE, CSE |
| Email | String | |
| Phone Number | String | |
| Description | String | Multi-line text, max length 1000 |

Save the table after adding the columns.

![Table columns](screenshots/07_table_columns.png)

### 2.3 Create sample records
1. Open the list with `u_institution_details.list` in the All menu filter.
2. Click **New** and enter records with different branches (ECE, EEE, CSE).
3. Create at least six records so each branch has more than one record.

![Sample records](screenshots/08_sample_records.png)

✅ **Milestone 2 result:** table `u_institution_details` with 6 sample records.

---

## Milestone 3 – Creation of the Read ACL

### 3.1 Elevate to security_admin
ACLs can only be created or edited by a user with the elevated `security_admin` role.
1. Click your **profile picture** (top right).
2. Choose **Elevate role**.
3. Tick **security_admin** and click **Update**.

![Elevate role menu](screenshots/09_elevate_role_menu.png)
![Elevate security_admin](screenshots/10_elevate_security_admin.png)

### 3.2 Open the ACL list
1. In the Application Navigator, search for `access control`.
2. Open **System Security > Access Control (ACL)**.
3. Click **New**.

![Access Control navigation](screenshots/11_access_control_navigation.png)
![ACL list and New button](screenshots/12_acl_list_new.png)

### 3.3 Fill in the ACL
| Field | Value |
|-------|-------|
| Type | `record` |
| Operation | `read` |
| Decision Type | Allow If |
| Name (table) | `Institution Details [u_institution_details]` (field: -- None --) |
| Active | ✔ |
| Advanced | ✔ |
| Admin overrides | ✔ |

### 3.4 Add the role
In the **Requires role** related list, click **Insert a new row** and add **bb1**.

### 3.5 Add the data condition
In the **Data Condition** section, add the filter: **Branch** — **is** — **EEE**.

### 3.6 Add the script
In the **Script** field (Advanced Condition), paste the script from `scripts/read_acl_script.js`:
```javascript
(function () {
    // Allow admin users full access
    if (gs.hasRole('admin')) {
        return true;
    }
    // Users with bb1 pass the script check.
    // EEE-only visibility comes from the ACL data condition "Branch is EEE".
    if (gs.hasRole('bb1')) {
        return true;
    }
    // Deny access for all others
    return false;
})();
```

### 3.7 Save
Click **Submit** to save the ACL.

![Read ACL form](screenshots/13_read_acl_form.png)
![Data condition and script](screenshots/14_read_acl_data_condition_script.png)

### 3.8 Verify the Read ACL
1. **Impersonate the EEE user** and open the Institution Details list.
2. Copy `u_institution_details.list` and paste it into the All menu filter to open the list.
3. **Impersonate Admin** and open the same list.

| Check | Expected | Screenshot |
|-------|----------|------------|
| User with **bb1** | Only EEE branch records | ![bb1](screenshots/15_verify_bb1_only_eee_records.png) |
| User **without the role** | No records to display | ![no role](screenshots/16_verify_no_role_no_records.png) |
| **Admin** | All records regardless of branch | ![admin](screenshots/17_verify_admin_all_records.png) |

✅ **Milestone 3 result:** read access is limited to EEE records for bb1 users, while admins see everything.

---

## Milestone 4 – Creation of the Create ACL (role bb2)

### 4.1 Steps
1. Make sure you are still elevated to `security_admin`.
2. Open **System Security > Access Control (ACL)** and click **New**.
3. Enter:
   | Field | Value |
   |-------|-------|
   | Type | `record` |
   | Operation | `create` |
   | Name | `u_institution_details` |
   | Active | ✔ |
   | Advanced | ✘ |
4. In **Requires role**, add **bb2**.
5. No data condition is needed.
6. Save the ACL record.

![Create ACL form](screenshots/18_create_acl_form.png)
![bb2 role](screenshots/19_create_acl_bb2_role.png)

### 4.2 Verify
A user with **bb1 and bb2** sees only EEE branch records and now also sees the **New** button.

![New button](screenshots/20_verify_new_button_bb1_bb2.png)

✅ **Milestone 4 result:** bb2 controls record creation.

---

## Milestone 5 – Creation of the Write ACL (role bb3)

### 5.1 Steps
1. Click **New** in the ACL list.
2. Enter:
   | Field | Value |
   |-------|-------|
   | Type | `record` |
   | Operation | `write` |
   | Name | `u_institution_details` |
   | Active | ✔ |
3. In **Requires role**, add **bb3**.
4. No data condition is needed.
5. Save the ACL record.

![Write ACL form](screenshots/21_write_acl_form.png)
![bb3 role](screenshots/22_write_acl_bb3_role.png)

### 5.2 Verify
A user with **bb1, bb2 and bb3** can view and edit EEE records and still sees the New button. In the list, double-click the **Description** cell, type text (for example "ACL is Executed") and confirm with the green tick.

![Inline edit](screenshots/23_verify_inline_edit_bb3.png)
![Description saved](screenshots/24_verify_description_saved.png)

✅ **Milestone 5 result:** bb3 controls record editing.

---

## Milestone 6 – Creation of the Delete ACL (role bb4)

### 6.1 Steps
1. Click **New** in the ACL list.
2. Enter:
   | Field | Value |
   |-------|-------|
   | Type | `record` |
   | Operation | `delete` |
   | Name | `u_institution_details` |
   | Active | ✔ |
3. In **Requires role**, add **bb4**.
4. No data condition is needed.
5. Save the ACL record.

![Delete ACL form](screenshots/25_delete_acl_form.png)
![bb4 role](screenshots/26_delete_acl_bb4_role.png)

### 6.2 Verify
A user with **bb1, bb2, bb3 and bb4** can see, create, edit and delete the EEE records.
1. Tick the checkbox next to an EEE record.
2. Open **Actions on selected rows...** and choose **Delete**.
3. Confirm by clicking **Delete** in the dialog.

![Delete action](screenshots/27_delete_action_menu.png)
![Delete confirmation](screenshots/28_delete_confirmation.png)

✅ **Milestone 6 result:** bb4 controls record deletion.

---

## Final ACL Summary
| # | Operation | Role | Data condition | Advanced script |
|---|-----------|------|----------------|-----------------|
| 1 | read | bb1 | Branch is EEE | Yes |
| 2 | create | bb2 | None | No |
| 3 | write | bb3 | None | No |
| 4 | delete | bb4 | None | No |

## Common Issues and Fixes
| Issue | Cause | Fix |
|-------|-------|-----|
| "New" ACL button shows a security error | `security_admin` not elevated | Elevate the role and retry |
| Record list is empty for the EEE user | Read ACL role or condition missing | Check bb1 is under *Requires role* and condition is Branch is EEE |
| Changes do not appear after adding roles | Session cached old roles | Stop impersonating and impersonate again |
| Admin cannot see records | Script or ACL misconfigured | Keep *Admin overrides* ticked and `gs.hasRole('admin')` in the script |
| Wrong table protected | Table name typed wrongly | Use `u_institution_details` |

## Update Set
The work was captured in the update set **ACL Project** (application scope: Global).
