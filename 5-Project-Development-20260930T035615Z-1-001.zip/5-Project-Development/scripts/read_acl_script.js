(function () {
    // Allow admin users full access
    if (gs.hasRole('admin')) {
        return true;
    }
    // Users with bb1 pass the script check.
    // EEE-only visibility comes from the ACL data condition "Branch is EEE".
    if (gs.hasRole('bb1')) {
        return true;
    }
    // Deny access for all others
    return false;
})();
