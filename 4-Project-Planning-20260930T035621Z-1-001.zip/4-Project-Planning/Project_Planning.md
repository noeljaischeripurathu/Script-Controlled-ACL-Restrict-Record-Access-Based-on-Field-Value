# Phase 4: Project Planning

## 4.1 Overview
The lab is planned for **3 hours** and split into six milestones. Each milestone has clear tasks, an expected output and a check that it is finished.

## 4.2 Work Breakdown Structure
| Milestone | Tasks | Output | Est. time |
|-----------|-------|--------|-----------|
| **M1 – Users & Roles** | Log in as admin; create EEE User; create roles bb1–bb4; assign the roles | User and 4 roles exist | 30 min |
| **M2 – Table & Data** | Create `u_institution_details`; add 7 fields; insert sample records for ECE, EEE, CSE | Table with 6 records | 40 min |
| **M3 – Read ACL** | Elevate to security_admin; create the read ACL; add role, data condition and script | Read ACL active | 30 min |
| **M4 – Create & Write ACLs** | Create ACL for bb2 (create) and bb3 (write) | Two ACLs active | 25 min |
| **M5 – Delete ACL** | Create ACL for bb4 (delete) | Delete ACL active | 15 min |
| **M6 – Testing & Publishing** | Impersonate users; verify; capture screenshots; document; push to GitHub | Test results and repository | 40 min |
| **Total** | | | **180 min** |

## 4.3 Timeline
```
0:00 ─ 0:30   M1  Users and Roles
0:30 ─ 1:10   M2  Table and Data
1:10 ─ 1:40   M3  Read ACL
1:40 ─ 2:05   M4  Create and Write ACLs
2:05 ─ 2:20   M5  Delete ACL
2:20 ─ 3:00   M6  Testing, Documentation, GitHub
```

## 4.4 Task Checklist
- [x] Log in with admin access
- [x] Create EEE User
- [x] Create roles bb1, bb2, bb3, bb4
- [x] Assign roles to EEE User
- [x] Create table `u_institution_details`
- [x] Add all fields
- [x] Insert sample records (ECE, EEE, CSE)
- [x] Elevate `security_admin`
- [x] Create Read ACL with data condition and script
- [x] Create Create ACL (bb2)
- [x] Create Write ACL (bb3)
- [x] Create Delete ACL (bb4)
- [x] Test as bb1 user, no-role user and admin
- [x] Capture screenshots
- [x] Write phase documents
- [x] Record demo video
- [x] Upload everything to GitHub

## 4.5 Resources Needed
| Resource | Use |
|----------|-----|
| ServiceNow instance with admin login | Build and test |
| security_admin elevation | Create ACLs |
| Browser and screenshot tool | Evidence for documents |
| Screen recorder | Demo video |
| GitHub account | Submission |

## 4.6 Roles and Responsibilities
| Team member | Reg No | Responsibility |
|-------------|--------|----------------|
| Noel Jais | C4S32208 | Project work across all phases |
| Nisha Devi P | C4S32202 | Project work across all phases |
| Selvinkumar S | C4S32210 | Project work across all phases |

All three members are from the Department of Physics and worked together on design, build, testing, documentation and the demonstration.

## 4.7 Deliverables
1. Working ACLs on `u_institution_details`.
2. ACL script (`read_acl_script.js`).
3. Screenshots of every milestone.
4. Test cases with results.
5. Phase-wise documents in GitHub.
6. Demo video.

## 4.8 Risk Register
| # | Risk | Likelihood | Impact | Mitigation |
|---|------|-----------|--------|-----------|
| 1 | Cannot create or edit ACLs | Medium | High | Elevate to `security_admin` first |
| 2 | Roles do not seem to apply after assignment | Medium | Medium | End impersonation and impersonate again, or log out and in |
| 3 | Wrong ACL is being evaluated | Low | Medium | Filter the ACL list by table name `u_institution_details` |
| 4 | Admin locked out of records | Low | High | Keep *Admin overrides* checked and `admin` allowed in the script |
| 5 | Table name typed incorrectly | Low | Medium | Use `u_institution_details` exactly |
| 6 | Time overrun | Low | Low | Follow the milestone order and timeline |

## 4.9 Definition of Done
The project is complete when all acceptance criteria in Phase 2 pass, screenshots are saved, the documents are uploaded to GitHub and the demo video link is available.
