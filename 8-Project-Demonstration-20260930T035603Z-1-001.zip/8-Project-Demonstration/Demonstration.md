# Phase 8: Project Demonstration

## 8.1 Demo Links
- **Demo video:** [https://drive.google.com/file/d/1otBEL14NNOl1m77vg9nPVpjpeB7yMm5c/view?usp=drivesdk](https://drive.google.com/file/d/1otBEL14NNOl1m77vg9nPVpjpeB7yMm5c/view?usp=drivesdk)
- **GitHub repository:** https://github.com/noeljaischeripurathu/Script-Controlled-ACL-Restrict-Record-Access-Based-on-Field-Value

## 8.2 Demo Objective
Show, from start to finish, that the four ACLs on `u_institution_details` allow and deny access correctly for an EEE user, a user without roles and an admin.

## 8.3 Presenters
| Name | Reg No | Department |
|------|--------|------------|
| Noel Jais | C4S32208 | Physics |
| Nisha Devi P | C4S32202 | Physics |
| Selvinkumar S | C4S32210 | Physics |

College: Mary Matha College of Arts and Science, Periyakulam, Theni

## 8.4 Before You Start (Checklist)
- [ ] ServiceNow instance is open and logged in as admin.
- [ ] Sample records for ECE, EEE and CSE exist.
- [ ] Roles bb1–bb4 are assigned to the EEE User.
- [ ] All four ACLs are active.
- [ ] Screen recording is running and the microphone works.

## 8.5 Demo Script (about 5 minutes)
| Time | Step | What to show | What to say |
|------|------|--------------|-------------|
| 0:00 | 1. Introduction | Title, name, project name | "This project restricts record access based on a field value using script-controlled ACLs." |
| 0:30 | 2. Users and roles | Users list and roles list | "I created EEE User and roles bb1 to bb4, one for each operation." |
| 1:00 | 3. Table and data | `u_institution_details` list as admin | "The table has six records across ECE, CSE and EEE." |
| 1:30 | 4. The ACLs | ACL list filtered by the table name | "There are four ACLs: read, create, write and delete." |
| 2:00 | 5. Read ACL details | Open read ACL: role, data condition, script | "Read needs bb1, the condition Branch is EEE, and this script." |
| 2:30 | 6. Test bb1 user | Impersonate the EEE user, open the list | "Only the EEE records are shown." |
| 3:00 | 7. Test no-role user | Impersonate a user without roles | "This user sees no records." |
| 3:20 | 8. Test admin | Impersonate admin | "Admin sees all six records." |
| 3:40 | 9. Create, write | Show the New button; edit Description | "bb2 gives the New button, bb3 allows editing." |
| 4:15 | 10. Delete | Select a record, Actions, Delete, confirm | "bb4 allows deletion." |
| 4:45 | 11. Conclusion | Summary slide or README | "Role and field value together control who can view, create, edit and delete." |

## 8.6 Key Points to Highlight
1. Access is enforced on the server, so it applies to lists, forms and portals.
2. The Read ACL uses three checks: role, data condition and script.
3. Each operation has its own role, giving least-privilege access.
4. Admin keeps full access.

## 8.7 Expected Outcome of the Demo
| Viewer | Sees |
|--------|------|
| bb1 user | Only EEE records |
| User without role | Nothing |
| Admin | All records |
| bb1 + bb2 | EEE records and New button |
| + bb3 | Can edit |
| + bb4 | Can delete |

## 8.8 Possible Questions and Answers
| Question | Answer |
|----------|--------|
| Why use a data condition instead of only a script? | Conditions are checked per record and are easier to read and maintain. |
| What does Admin overrides do? | It lets users with the admin role pass the ACL automatically. |
| Why elevate to security_admin? | Creating or editing ACLs is a high-security action that needs the elevated role. |
| Why separate roles for each operation? | To give users only the access they need. |
| What happens if no ACL grants access? | The user is denied. |
| How was it tested? | By impersonating an EEE user, a user without roles and an admin. |

## 8.9 Project Repository Walkthrough
1. **README.md** – overview, student details, links.
2. **Phases 1–4** – ideation, requirements, design and plan.
3. **Phase 5** – build steps, script and 28 screenshots.
4. **Phase 6** – seven test cases, all passed.
5. **Phase 7** – final documentation and the original lab PDF.
6. **Phase 8** – this demonstration guide.
