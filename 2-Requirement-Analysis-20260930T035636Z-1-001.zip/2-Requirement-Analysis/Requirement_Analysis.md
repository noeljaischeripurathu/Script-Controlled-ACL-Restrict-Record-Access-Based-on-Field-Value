# Phase 2: Requirement Analysis

## 2.1 Purpose
This document lists everything the project must do (functional), how well it must do it (non-functional), the data it needs, the roles involved and the environment required.

## 2.2 Functional Requirements
| ID | Requirement | Priority |
|----|-------------|----------|
| FR-1 | Create a test user named **EEE User** with a valid email. | High |
| FR-2 | Create custom roles **bb1, bb2, bb3, bb4**. | High |
| FR-3 | Assign all four roles to the EEE User. | High |
| FR-4 | Create the custom table **u_institution_details** (Institution Details). | High |
| FR-5 | Add the fields: Student Roll Number, Student Name, Faculty Name, Branch, Email, Phone Number, Description. | High |
| FR-6 | Insert multiple sample records with Branch values ECE, EEE and CSE. | High |
| FR-7 | Create a **Read ACL** requiring bb1, with data condition Branch is EEE and an advanced script. | High |
| FR-8 | Create a **Create ACL** requiring bb2 so the New button appears. | High |
| FR-9 | Create a **Write ACL** requiring bb3 so records can be edited. | High |
| FR-10 | Create a **Delete ACL** requiring bb4 so records can be deleted. | High |
| FR-11 | Admin can view all records regardless of branch. | High |
| FR-12 | A user without the roles sees no records. | High |

## 2.3 Non-Functional Requirements
| ID | Requirement |
|----|-------------|
| NFR-1 | **Security:** access rules are enforced on the server for lists, forms and portals. |
| NFR-2 | **Auditability:** every rule is visible in the ACL list (System Security > Access Control). |
| NFR-3 | **Maintainability:** each operation has its own ACL and role, so one can be changed without affecting the others. |
| NFR-4 | **Usability:** allowed users see the New button, inline edit and delete actions as expected. |
| NFR-5 | **Time:** the complete lab should be finished in about 3 hours. |
| NFR-6 | **Simplicity:** the ACL script stays short and readable. |

## 2.4 Data Requirements
Table: **Institution Details** (`u_institution_details`), not extending any other table.

| Field | Type | Notes |
|-------|------|-------|
| Student Roll Number | String | Default value uses `javascript:global.getNextObjNumberPadded();`, giving numbers like INS0001001 |
| Student Name | Reference (User) | Points to the sys_user table |
| Faculty Name | Reference (User) | Points to the sys_user table |
| Branch | Choice | ECE, EEE, CSE |
| Email | String | |
| Phone Number | String | |
| Description | String (multi-line) | Used in testing the write ACL |

### Sample Data (as used in the lab)
| Roll No | Student | Faculty | Branch |
|---------|---------|---------|--------|
| INS0001006 | Praneeth | ITIL User | ECE |
| INS0001008 | Abraham Lincoln | Malla Sravan kumar | CSE |
| INS0001005 | Srinu Nandipalli | ITIL User | ECE |
| INS0001007 | Guna Sai | Abel Tuter | EEE |
| INS0001001 | Yaswanth Nikku | Abraham Lincoln | CSE |
| INS0001004 | Prashanth Reddy | Abel Tuter | EEE |

Total records: **6** (2 ECE, 2 CSE, 2 EEE).

## 2.5 Roles and Permissions Matrix
| Role | Read | Create | Write | Delete |
|------|:----:|:------:|:-----:|:------:|
| admin | Yes | Yes | Yes | Yes |
| bb1 | Yes (EEE only) | No | No | No |
| bb2 | No | Yes | No | No |
| bb3 | No | No | Yes | No |
| bb4 | No | No | No | Yes |
| No role | No | No | No | No |

> The custom roles are designed to be combined. A user with bb1 + bb2 + bb3 + bb4 (the EEE User) can read, create, edit and delete EEE records.

## 2.6 User Stories
1. As an **EEE user**, I want to see only EEE students so that I do not see other branches' data.
2. As a **user without roles**, I should see no student records so that private data stays private.
3. As an **admin**, I want to see every record so that I can manage the whole system.
4. As a **data operator with bb2**, I want a New button so that I can add records.
5. As an **editor with bb3**, I want to edit records so that I can keep them up to date.
6. As a **manager with bb4**, I want to delete records so that I can remove wrong entries.

## 2.7 Environment and Prerequisites
| Requirement | Detail |
|-------------|--------|
| Instance | A ServiceNow instance (personal developer instance is enough) |
| Login | Admin access |
| Extra privilege | Ability to elevate to `security_admin` to create ACLs |
| Browser | Any modern browser |
| Application scope | Global |

## 2.8 Acceptance Criteria
- ✅ bb1 user sees only EEE records.
- ✅ User without roles sees "No records to display".
- ✅ Admin sees all 6 records.
- ✅ bb1 + bb2 user sees the New button.
- ✅ bb1 + bb2 + bb3 user can edit a record.
- ✅ bb1 + bb2 + bb3 + bb4 user can delete a record.
