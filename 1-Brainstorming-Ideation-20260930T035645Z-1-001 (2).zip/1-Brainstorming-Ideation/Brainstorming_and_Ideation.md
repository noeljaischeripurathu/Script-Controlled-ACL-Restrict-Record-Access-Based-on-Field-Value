# Phase 1: Brainstorming & Ideation

## 1.1 Background
ServiceNow stores business data in tables. By default, a user who has access to a table can often see every record in it. Institutions that keep student data for many branches in a single table need a way to limit each user to only the data they are meant to see. ServiceNow's security model answers this with **Access Control Lists (ACLs)**.

## 1.2 Problem Statement
Student records for ECE, EEE and CSE branches are stored in one custom table. Without record-level security:
- Any user with table access could read the data of every branch.
- Sensitive details such as email and phone number could be exposed.
- Users could edit or delete records that do not belong to them.
- Interface-only hiding (form/list layout tricks) does not stop a determined user.

## 1.3 Goals of the Project
1. Restrict record visibility by the value of the **Branch** field.
2. Allow each operation (read, create, write, delete) to be granted separately through its own role.
3. Keep administrators fully in control.
4. Prove the design works by testing with three kinds of users.

## 1.4 Brainstorming Questions and Answers
| Question | Answer |
|----------|--------|
| Who should see EEE records? | Users holding the custom role bb1 (and admins). |
| Who should see nothing? | Users without any of the custom roles. |
| How do we filter by branch? | ACL data condition: Branch is EEE. |
| How do we add custom logic? | Advanced ACL with a server-side script. |
| How do we separate permissions? | One custom role per operation: bb1, bb2, bb3, bb4. |
| How do we test safely? | Impersonate users instead of sharing passwords. |

## 1.5 Options Considered
| Option | How it works | Pros | Cons | Decision |
|--------|--------------|------|------|----------|
| UI Policy / Client Script | Hides fields or buttons in the browser | Simple, quick | Client-side only; can be bypassed through lists, APIs or reports | Rejected |
| Business Rule (before query) | Adds a filter to every query | Filters at query time | Not the standard security model; harder to audit | Considered, not chosen |
| Table-level roles only | Requires a role for the whole table | Very simple | Cannot filter by branch; all-or-nothing | Rejected |
| **Script-controlled ACL** | Server checks role, condition and script for every access | Server-side, auditable, per-operation, standard | Needs security_admin; needs careful testing | **Selected** |

## 1.6 Proposed Idea
Create four custom roles and four ACLs on `u_institution_details`:
- **Read ACL** requires role **bb1**, adds the data condition **Branch is EEE**, and uses an advanced script that allows admins and bb1 holders and denies everyone else.
- **Create ACL** requires role **bb2**.
- **Write ACL** requires role **bb3**.
- **Delete ACL** requires role **bb4**.

## 1.7 Stakeholders and Users
| User | Description | Expected access |
|------|-------------|-----------------|
| Admin | System administrator | Everything |
| EEE User | Test user with roles bb1–bb4 | EEE records; create, edit and delete |
| User without roles | Any other user | No records |

## 1.8 Assumptions
- The instance is available and the tester has admin access.
- The tester can elevate to `security_admin`.
- Sample records exist for all three branches.

## 1.9 Constraints
- The lab is planned for about 3 hours.
- Only one custom table is used.
- Testing is done through impersonation on the same instance.

## 1.10 Expected Benefits
- Data privacy between branches.
- Least-privilege access for every operation.
- Easy auditing because all rules appear in the ACL list.
- A reusable pattern for any table that needs field-based access rules.
